## Version 1.4.0

- Sorted the song list (should help with syncing online)
- Updated the README to better explain how to install songs when installing with r2modman