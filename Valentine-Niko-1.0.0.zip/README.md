# Niko Employee v1.0
### Niko Joins the company

## Features
- Adds Niko as a suit.

## Instructions
Place the ```thing``` in the ```thing``` folder.

## Changelog
	- v1.0.0
		- Release
		- Niko joins the company