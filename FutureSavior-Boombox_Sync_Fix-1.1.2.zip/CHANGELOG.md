- **1.1.2**
    - Fixed some typos in README and CHANGELOG.

- **1.1.1**
    - Updated README with multiple sections.

- **1.1.0**
    - Added compatibility with late join mods like ShipLobby and LateCompany.
    - Fixed an issue where the boomboxes don't sync up if the host lands the ship and IMMEDIATELY picks up the boombox BEFORE the round has loaded in.
    - Updated README.

- **1.0.0**
    - Mod release