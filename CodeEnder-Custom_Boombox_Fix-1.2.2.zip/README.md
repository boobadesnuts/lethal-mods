# CustomBoomboxFix
Workaround to allow music content mods to easily integrate with Custom Boombox Music

## Usage
Creates `plugins/Custom Songs` directory and copies all folders inside plugins with name 'Custome Songs' into main custom boombox folder. Read decompiled code before use.

CLIENT SIDE MOD.

ADVANCED USERS ONLY

DO NOT UPLOAD COPYRIGHTED CONTENT TO THUNDERSTORE

## Support and Feedback
I have stopped answering questions due to a wave of low effort modders, and the discord constantly being flooded with the same 3 questions.

## Credits
Mod created by CodeEnder.

[Custom Boombox Music](https://thunderstore.io/c/lethal-company/p/Steven/Custom_Boombox_Music/) created by Steven.
