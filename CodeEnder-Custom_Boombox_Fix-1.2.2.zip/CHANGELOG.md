## CustomBoomboxFix 1.2.2
- Removed instructions and guide due to large influx of stupid questions, and low effort (copyright infringing) mods

## CustomBoomboxFix 1.2.0
- Added functionality to enable and disable content mods
- Updated README to hopefully answer questions before they get asked

## CustomBoomboxFix 1.1.0

### Added
- TLDR: Fixed issues with modloaders not correctly installing content mods
- Functionality to recursively search the `plugins` folder for any directories named `Custom Songs`.
- Automatically copy all `.mp3` and `.wav` files found in these directories to the `Custom Songs` folder managed by the mod.

